import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyToken } from '@/app/api/auth/route'

// GET /api/assignments - List all assignments (public — anyone can view)
export async function GET() {
  try {
    const assignments = await db.assignment.findMany({
      orderBy: { createdAt: 'desc' },
    })
    // Strip file data for list response (too large)
    const lightweight = assignments.map(({ fileData, ...rest }) => ({
      ...rest,
      hasFile: !!fileData,
    }))
    return NextResponse.json({ assignments: lightweight })
  } catch (error) {
    console.error('Failed to fetch assignments:', error)
    return NextResponse.json(
      { error: 'Failed to fetch assignments' },
      { status: 500 }
    )
  }
}

// POST /api/assignments - Create a new assignment (admin only)
export async function POST(req: NextRequest) {
  try {
    const token = req.cookies.get('admin_token')?.value
    if (!verifyToken(token)) {
      return NextResponse.json(
        { error: 'Unauthorized — admin login required' },
        { status: 403 }
      )
    }

    const formData = await req.formData()
    const title = formData.get('title') as string
    const description = (formData.get('description') as string) || ''
    const course = (formData.get('course') as string) || ''
    const file = formData.get('file') as File | null

    if (!title || title.trim() === '') {
      return NextResponse.json(
        { error: 'Title is required' },
        { status: 400 }
      )
    }

    let fileData: string | null = null
    let fileName: string | null = null
    let fileType: string | null = null
    let fileSize: number | null = null

    if (file && file.size > 0) {
      // Limit file size to ~10MB to keep DB manageable
      if (file.size > 10 * 1024 * 1024) {
        return NextResponse.json(
          { error: 'File size must be less than 10MB' },
          { status: 400 }
        )
      }
      const arrayBuffer = await file.arrayBuffer()
      const buffer = Buffer.from(arrayBuffer)
      fileData = buffer.toString('base64')
      fileName = file.name
      fileType = file.type || 'application/octet-stream'
      fileSize = file.size
    }

    const assignment = await db.assignment.create({
      data: {
        title: title.trim(),
        description: description.trim() || null,
        course: course.trim() || null,
        fileName,
        fileData,
        fileType,
        fileSize,
      },
    })

    // Don't return fileData
    const { fileData: _fd, ...rest } = assignment
    return NextResponse.json({
      assignment: { ...rest, hasFile: !!fileData },
    })
  } catch (error) {
    console.error('Failed to create assignment:', error)
    return NextResponse.json(
      { error: 'Failed to create assignment' },
      { status: 500 }
    )
  }
}

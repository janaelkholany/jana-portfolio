import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyToken } from '@/app/api/auth/route'

type RouteParams = { params: Promise<{ id: string }> }

// GET /api/assignments/[id] - Get single assignment (public — anyone can download)
export async function GET(req: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params
    const assignment = await db.assignment.findUnique({ where: { id } })
    if (!assignment) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }

    const url = new URL(req.url)
    const download = url.searchParams.get('download')

    // If download requested and file exists, stream file
    if (download && assignment.fileData && assignment.fileName) {
      const buffer = Buffer.from(assignment.fileData, 'base64')
      const headers = new Headers({
        'Content-Type': assignment.fileType || 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${encodeURIComponent(assignment.fileName)}"`,
        'Content-Length': buffer.length.toString(),
      })
      return new NextResponse(buffer, { headers })
    }

    // Otherwise return metadata only
    const { fileData, ...rest } = assignment
    return NextResponse.json({ assignment: { ...rest, hasFile: !!fileData } })
  } catch (error) {
    console.error('Failed to fetch assignment:', error)
    return NextResponse.json({ error: 'Failed to fetch assignment' }, { status: 500 })
  }
}

// PUT /api/assignments/[id] - Update assignment (admin only)
export async function PUT(req: NextRequest, { params }: RouteParams) {
  try {
    const token = req.cookies.get('admin_token')?.value
    if (!verifyToken(token)) {
      return NextResponse.json(
        { error: 'Unauthorized — admin login required' },
        { status: 403 }
      )
    }
    const { id } = await params
    const existing = await db.assignment.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }

    const formData = await req.formData()
    const title = formData.get('title') as string
    const description = (formData.get('description') as string) ?? ''
    const course = (formData.get('course') as string) ?? ''
    const file = formData.get('file') as File | null
    const removeFile = formData.get('removeFile') === 'true'

    if (!title || title.trim() === '') {
      return NextResponse.json({ error: 'Title is required' }, { status: 400 })
    }

    let fileData: string | null | undefined = undefined
    let fileName: string | null | undefined = undefined
    let fileType: string | null | undefined = undefined
    let fileSize: number | null | undefined = undefined

    if (file && file.size > 0) {
      if (file.size > 10 * 1024 * 1024) {
        return NextResponse.json({ error: 'File size must be less than 10MB' }, { status: 400 })
      }
      const arrayBuffer = await file.arrayBuffer()
      const buffer = Buffer.from(arrayBuffer)
      fileData = buffer.toString('base64')
      fileName = file.name
      fileType = file.type || 'application/octet-stream'
      fileSize = file.size
    } else if (removeFile) {
      fileData = null
      fileName = null
      fileType = null
      fileSize = null
    }
    // else: keep existing file (undefined means no change)

    const updateData: {
      title: string
      description: string | null
      course: string | null
      fileData?: string | null
      fileName?: string | null
      fileType?: string | null
      fileSize?: number | null
    } = {
      title: title.trim(),
      description: description.trim() || null,
      course: course.trim() || null,
    }

    if (fileData !== undefined) {
      updateData.fileData = fileData
      updateData.fileName = fileName ?? null
      updateData.fileType = fileType ?? null
      updateData.fileSize = fileSize ?? null
    }

    const assignment = await db.assignment.update({
      where: { id },
      data: updateData,
    })

    const { fileData: _fd, ...rest } = assignment
    return NextResponse.json({
      assignment: { ...rest, hasFile: !!assignment.fileData },
    })
  } catch (error) {
    console.error('Failed to update assignment:', error)
    return NextResponse.json({ error: 'Failed to update assignment' }, { status: 500 })
  }
}

// DELETE /api/assignments/[id] - Delete assignment (admin only)
export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    const token = req.cookies.get('admin_token')?.value
    if (!verifyToken(token)) {
      return NextResponse.json(
        { error: 'Unauthorized — admin login required' },
        { status: 403 }
      )
    }
    const { id } = await params
    const existing = await db.assignment.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }
    await db.assignment.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Failed to delete assignment:', error)
    return NextResponse.json({ error: 'Failed to delete assignment' }, { status: 500 })
  }
}
